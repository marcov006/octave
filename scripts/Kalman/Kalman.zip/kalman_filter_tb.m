MC=100;

p0 = 0;
v0 = 0;
x_past = [p0;
          v0];
u  = 10;
delta_t = 0.1;

F=[1 delta_t;
   0 1];
B=[0.5*delta_t*delta_t;
               delta_t];
P=zeros(2);

U=eye(2);
Uinit=10*U;
Q=U*U';

H = [1 0;
     0 1];
W = 10*eye(2);
R = W*W';

figure;hold on;
%axis([ 0   600     0   100]*5);
h1=subplot(2,1,1);hold on;
h2=subplot(2,1,2); hold on;
x = [-10;-10];%x_past + Uinit*randn(size(x_past));
for it = 1:MC
    x_new = F*x_past + B*u + U*randn(size(x_past));
    z     = H*x_new + W*randn(size(H*x_new));
    [x P] = kalman_filter_iteration(x,F,P,B,u,Q,z,H,R);
    hold on;
    plot(h1,x_new(1),x_new(2),'ob');
    plot(h1,x(1)    ,x(2),    'xr');
    plot(h1,z(1)    ,z(2),'.g');
    plot(h2,it,log10(sum(abs(x_new-x).^2)),'rx');
    plot(h2,it,log10(sum(abs(x_new-z).^2)),'g.');
    drawnow;
    pause(20/MC);
    x_past = x_new;
end

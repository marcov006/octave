function [xap, Pap] = kalman_update(x,P,z,H,R)
r    = z-H*x;
S    = H*P*H'+R;
K    = P*H'*inv(S);
xap  = x+K*r;
Pap  = (eye(size(P))-K*H)*P;
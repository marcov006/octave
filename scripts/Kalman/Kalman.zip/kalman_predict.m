function [x1, P1] = kalman_predict(x0,F,P0,B,u,Q)

x1 = F*x0 + B*u;
P1 = F*P0*F' + Q;